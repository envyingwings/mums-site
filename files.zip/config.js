// Fill these in from your Supabase project: Settings > API
// SUPABASE_ANON_KEY is safe to expose publicly — it only allows what
// your Row Level Security policies permit (see schema.sql).
const SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-PUBLIC-KEY';

// Your business's timezone (IANA name). All slot calculations use this,
// so customers in other timezones still see YOUR local availability.
const BUSINESS_TIMEZONE = 'Europe/London';

// How far ahead customers can book (days)
const BOOKING_WINDOW_DAYS = 60;

// Minimum notice required before a booking (hours)
const MIN_NOTICE_HOURS = 2;
